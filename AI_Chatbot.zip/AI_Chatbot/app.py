from flask import Flask, jsonify, request
from config import Config
from database.models import db


def create_app(test_config=None):
    app = Flask(__name__)
    app.config.from_object(Config)
    if test_config:
        app.config.update(test_config)
    db.init_app(app)

    from routes import auth, chat, api
    app.register_blueprint(auth.bp)
    app.register_blueprint(chat.bp)
    app.register_blueprint(api.bp)

    @app.errorhandler(404)
    def not_found(_):
        if request.path.startswith("/api/"):
            return jsonify({"success": False, "error": "Not found."}), 404
        return "Page not found", 404

    @app.errorhandler(500)
    def server_error(_):
        if request.path.startswith("/api/"):
            return jsonify({"success": False, "error": "Internal server error."}), 500
        return "Something went wrong.", 500

    with app.app_context():
        db.create_all()  # creates SQLite file and tables if missing
    return app


if __name__ == "__main__":
    create_app().run(debug=False, port=5000)
