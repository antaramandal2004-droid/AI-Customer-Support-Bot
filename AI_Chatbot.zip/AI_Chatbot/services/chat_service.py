from database.models import Conversation

MAX_TITLE_WORDS = 7


def make_title(text):
    """Simple, reliable title: first few words of the first message."""
    words = text.replace("\n", " ").split()[:MAX_TITLE_WORDS]
    title = " ".join(words).rstrip("?.!,:;")
    return title[:60] or "New Chat"


def get_owned_conversation(user_id, conversation_id):
    """Returns the conversation only if it belongs to the user, else None."""
    return Conversation.query.filter_by(id=conversation_id, user_id=user_id).first()


def build_history(conversation, limit):
    msgs = [{"role": m.role, "content": m.content} for m in conversation.messages][-limit:]
    while msgs and msgs[0]["role"] != "user":  # Claude requires a user-first list
        msgs.pop(0)
    return msgs
