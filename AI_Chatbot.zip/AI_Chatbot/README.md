# AI-Powered Chatbot (Flask + SQLite + Claude)

Web chatbot with registration/login, per-user conversation history, dark mode and Claude as the AI engine.

## Setup
```
python -m venv venv
venv\Scripts\activate        # Windows
source venv/bin/activate     # Linux/macOS
pip install -r requirements.txt
cp .env.example .env         # then edit .env
```
Get an API key at https://console.anthropic.com, put it in `.env` as `ANTHROPIC_API_KEY=`, and set a random `SECRET_KEY`.

## Run
`python app.py` → open http://127.0.0.1:5000

## Test
`pytest` (Claude is mocked; no real API calls)

## Structure
`app.py` factory · `config.py` · `database/models.py` (User, Conversation, Message) · `services/` (Claude call, history/title helpers) · `routes/` (auth, chat page, JSON API) · `templates/` · `static/` · `tests/`

## API
`POST /api/chat`, `GET|POST /api/conversations`, `GET|DELETE /api/conversations/<id>`
