const $ = (id) => document.getElementById(id);
const messagesEl = $("messages"), input = $("input"), sendBtn = $("sendBtn");
const welcomeHTML = messagesEl.innerHTML;
let currentId = null, busy = false;

async function api(url, options = {}) {
  const res = await fetch(url, { headers: { "Content-Type": "application/json" }, ...options });
  if (res.status === 401) { window.location = "/login"; throw new Error("auth"); }
  const data = await res.json().catch(() => ({ success: false, error: "Unexpected server response." }));
  if (!data.success) throw new Error(data.error || "Request failed.");
  return data;
}

function addMessage(role, text, iso) {
  const w = $("welcome"); if (w) w.remove();
  const div = document.createElement("div");
  div.className = "msg " + role;
  div.textContent = text;
  if (iso) { const t = document.createElement("small"); t.textContent = new Date(iso).toLocaleString(); div.appendChild(t); }
  messagesEl.appendChild(div);
  messagesEl.scrollTop = messagesEl.scrollHeight;
}

async function loadConversations() {
  const { conversations } = await api("/api/conversations");
  const list = $("convList"); list.innerHTML = "";
  conversations.forEach((c) => {
    const row = document.createElement("div");
    row.className = "conv" + (c.id === currentId ? " active" : "");
    const title = document.createElement("span"); title.textContent = c.title;
    const del = document.createElement("button"); del.textContent = "🗑"; del.title = "Delete";
    del.onclick = async (e) => {
      e.stopPropagation();
      if (!confirm("Delete this conversation?")) return;
      try { await api("/api/conversations/" + c.id, { method: "DELETE" }); } catch (err) { return alert(err.message); }
      if (c.id === currentId) newChat();
      loadConversations();
    };
    row.append(title, del);
    row.onclick = () => openConversation(c.id);
    list.appendChild(row);
  });
}

async function openConversation(id) {
  try {
    const data = await api("/api/conversations/" + id);
    currentId = id; $("chatTitle").textContent = data.conversation.title;
    messagesEl.innerHTML = "";
    data.messages.forEach((m) => addMessage(m.role, m.content, m.created_at));
    $("sidebar").classList.remove("open"); loadConversations();
  } catch (err) { alert(err.message); }
}

function newChat() {
  currentId = null; $("chatTitle").textContent = "New Chat";
  messagesEl.innerHTML = welcomeHTML; bindChips();
  $("sidebar").classList.remove("open"); loadConversations();
}

async function send(text) {
  text = text.trim();
  if (!text || busy) return;
  busy = true; sendBtn.disabled = true; input.value = "";
  addMessage("user", text);
  const typing = document.createElement("div");
  typing.className = "msg assistant typing"; typing.innerHTML = "<i></i><i></i><i></i>";
  messagesEl.appendChild(typing); messagesEl.scrollTop = messagesEl.scrollHeight;
  try {
    const data = await api("/api/chat", { method: "POST", body: JSON.stringify({ message: text, conversation_id: currentId }) });
    typing.remove();
    currentId = data.conversation.id; $("chatTitle").textContent = data.conversation.title;
    addMessage("assistant", data.assistant_message.content, data.assistant_message.created_at);
    loadConversations();
  } catch (err) {
    typing.remove(); if (err.message !== "auth") addMessage("error", err.message);
  } finally { busy = false; sendBtn.disabled = false; input.focus(); }
}

function bindChips() { document.querySelectorAll(".chip").forEach((c) => (c.onclick = () => send(c.textContent))); }

sendBtn.onclick = () => send(input.value);
input.addEventListener("keydown", (e) => { if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); send(input.value); } });
$("newChatBtn").onclick = newChat;
$("menuBtn").onclick = () => $("sidebar").classList.toggle("open");
$("themeBtn").onclick = () => {
  const next = document.documentElement.dataset.theme === "dark" ? "light" : "dark";
  document.documentElement.dataset.theme = next; localStorage.setItem("theme", next);
};
bindChips(); loadConversations();
