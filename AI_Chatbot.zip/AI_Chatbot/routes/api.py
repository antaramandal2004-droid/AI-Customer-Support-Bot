from functools import wraps
from flask import Blueprint, current_app, jsonify, request, session
from database.models import db, Conversation, Message, now
from services.claude_service import ClaudeError, generate_response
from services.chat_service import build_history, get_owned_conversation, make_title

bp = Blueprint("api", __name__, url_prefix="/api")


def fail(message, status):
    return jsonify({"success": False, "error": message}), status


def login_required(view):
    @wraps(view)
    def wrapper(*args, **kwargs):
        if "user_id" not in session:
            return fail("Authentication required.", 401)
        return view(*args, **kwargs)
    return wrapper


def conv_dict(c):
    return {"id": c.id, "title": c.title, "updated_at": c.updated_at.isoformat() + "Z"}


@bp.get("/conversations")
@login_required
def list_conversations():
    items = (Conversation.query.filter_by(user_id=session["user_id"])
             .order_by(Conversation.updated_at.desc()).all())
    return jsonify({"success": True, "conversations": [conv_dict(c) for c in items]})


@bp.post("/conversations")
@login_required
def create_conversation():
    conv = Conversation(user_id=session["user_id"])
    try:
        db.session.add(conv)
        db.session.commit()
    except Exception:
        db.session.rollback()
        return fail("Could not create conversation.", 500)
    return jsonify({"success": True, "conversation": conv_dict(conv)}), 201


@bp.get("/conversations/<int:conversation_id>")
@login_required
def get_conversation(conversation_id):
    conv = get_owned_conversation(session["user_id"], conversation_id)
    if not conv:
        return fail("Conversation not found.", 404)
    return jsonify({"success": True, "conversation": conv_dict(conv),
                    "messages": [m.to_dict() for m in conv.messages]})


@bp.delete("/conversations/<int:conversation_id>")
@login_required
def delete_conversation(conversation_id):
    conv = get_owned_conversation(session["user_id"], conversation_id)
    if not conv:
        return fail("Conversation not found.", 404)
    try:
        db.session.delete(conv)  # messages removed via cascade
        db.session.commit()
    except Exception:
        db.session.rollback()
        return fail("Could not delete conversation.", 500)
    return jsonify({"success": True})


@bp.post("/chat")
@login_required
def chat():
    data = request.get_json(silent=True)
    if not isinstance(data, dict):
        return fail("Invalid request.", 400)
    text = data.get("message")
    if not isinstance(text, str) or not text.strip():
        return fail("Message cannot be empty.", 400)
    text = text.strip()
    if len(text) > current_app.config["MAX_MESSAGE_LENGTH"]:
        return fail("Message is too long.", 400)

    conv_id = data.get("conversation_id")
    if conv_id is None:
        conv = Conversation(user_id=session["user_id"], title=make_title(text))
        db.session.add(conv)
        db.session.flush()
    else:
        if not isinstance(conv_id, int) or isinstance(conv_id, bool):
            return fail("Invalid conversation.", 400)
        conv = get_owned_conversation(session["user_id"], conv_id)
        if not conv:
            return fail("Conversation not found.", 404)
        if conv.title == "New Chat":
            conv.title = make_title(text)

    history = build_history(conv, current_app.config["MAX_HISTORY_MESSAGES"])
    history.append({"role": "user", "content": text})
    try:
        answer = generate_response(history)
    except ClaudeError as exc:
        db.session.rollback()
        return fail(str(exc), 502)

    try:
        user_msg = Message(conversation_id=conv.id, role="user", content=text)
        bot_msg = Message(conversation_id=conv.id, role="assistant", content=answer)
        db.session.add_all([user_msg, bot_msg])
        conv.updated_at = now()
        db.session.commit()
    except Exception:
        db.session.rollback()
        return fail("Could not save the conversation.", 500)
    return jsonify({"success": True, "conversation": conv_dict(conv),
                    "user_message": user_msg.to_dict(), "assistant_message": bot_msg.to_dict()})
