from flask import Blueprint, redirect, render_template, session, url_for
from database.models import db, User

bp = Blueprint("chat", __name__)


@bp.get("/chat")
def chat_page():
    user = db.session.get(User, session["user_id"]) if "user_id" in session else None
    if not user:
        session.clear()
        return redirect(url_for("auth.login"))
    return render_template("chat.html", username=user.username)
