import pytest
from app import create_app
from database.models import Conversation, Message
import routes.api as api_module


@pytest.fixture
def app():
    return create_app({"TESTING": True, "SQLALCHEMY_DATABASE_URI": "sqlite:///:memory:",
                       "SECRET_KEY": "test", "ANTHROPIC_API_KEY": "test"})


@pytest.fixture
def client(app, monkeypatch):
    monkeypatch.setattr(api_module, "generate_response", lambda msgs: "mock reply")  # no real API calls
    return app.test_client()


def register(c, email="a@b.com", pw="password123"):
    return c.post("/register", data={"username": "alice", "email": email, "password": pw})


def login(c, email="a@b.com", pw="password123"):
    return c.post("/login", data={"email": email, "password": pw})


def test_register_and_duplicate(client):
    assert register(client).status_code == 302
    assert register(client).status_code == 400


def test_login_logout(client):
    register(client)
    assert login(client, pw="wrongpass1").status_code == 401
    assert login(client).status_code == 302
    assert client.get("/chat").status_code == 200
    client.post("/logout")
    assert client.get("/chat").status_code == 302


def test_api_requires_login(client):
    assert client.post("/api/chat", json={"message": "hi"}).status_code == 401


def test_chat_flow_and_validation(client, app):
    register(client); login(client)
    assert client.post("/api/chat", json={"message": "  "}).status_code == 400
    assert client.post("/api/chat", json={"message": "hi", "conversation_id": 999}).status_code == 404
    r = client.post("/api/chat", json={"message": "What is machine learning?"})
    assert r.status_code == 200 and r.json["assistant_message"]["content"] == "mock reply"
    with app.app_context():
        assert Message.query.count() == 2


def test_ownership_and_cascade(client, app):
    register(client); login(client)
    cid = client.post("/api/chat", json={"message": "hello"}).json["conversation"]["id"]
    client.post("/logout")
    register(client, "c@d.com"); login(client, "c@d.com")
    assert client.get(f"/api/conversations/{cid}").status_code == 404
    assert client.delete(f"/api/conversations/{cid}").status_code == 404
    client.post("/logout"); login(client)
    assert client.delete(f"/api/conversations/{cid}").status_code == 200
    with app.app_context():
        assert Message.query.count() == 0 and Conversation.query.count() == 0
